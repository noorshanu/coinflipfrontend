/* eslint-disable @next/next/no-img-element */
"use client"
import "../globals.css";
import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/context/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import { useRouter } from "next/navigation";

// Define the Game type (copied from games/page.tsx)
type Game = {
    _id: string;
    startTime: string;
    totalPool: string;
    result: string;
    centers: string[];
    members: {
        id: string;
        centerId: string;
        amount: string;
        bet: string;
        result: string;
    }[];
};

// Entry type for local form
interface BetEntry {
    id: string;
    option: "Heads" | "Tails";
    amount: number;
    timestamp: Date;
}

// Add at the top, after your imports
type GameHistory = {
    _id: string;
    result: string;
    createdAt: string;
    entries: {
        id: string;
        centerId: string;
        amount: string;
        bet: string;
        result: string;
        _id: string;
    }[];
};

export default function CenterHome() {
    const { user } = useAuth();
    const [game, setGame] = useState<Game | null>(null);
    const [gameId, setGameId] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [timeLeft, setTimeLeft] = useState<string>("");
    const [selected, setSelected] = useState<"Heads" | "Tails" | null>(null);
    const [amount, setAmount] = useState<string>("");
    const [entries, setEntries] = useState<BetEntry[]>([]);
    const [showSuccess, setShowSuccess] = useState<boolean>(false);
    const [lastAddedId, setLastAddedId] = useState<string>("");
    const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
    const entriesRef = useRef<BetEntry[]>([]);
    const hasSubmittedRef = useRef(false);
    const [gameState, setGameState] = useState<'timer' | 'flipping' | 'result'>('timer');
    const [flippingAnimation, setFlippingAnimation] = useState<'heads' | 'tails'>("heads");
    const [finalResult, setFinalResult] = useState<'heads' | 'tails' | null>(null);
    const [resultText, setResultText] = useState<string>("");
    const [showCelebration, setShowCelebration] = useState(false);
    const router = useRouter();
    const [userPoints, setUserPoints] = useState<number>(0);
    const [historyGames, setHistoryGames] = useState<GameHistory[]>([]);
    const [historyLoading, setHistoryLoading] = useState(true);
    const [isBettingDisabled, setIsBettingDisabled] = useState(false);

    // Keep entriesRef in sync
    useEffect(() => {
        entriesRef.current = entries;
    }, [entries]);

    // Fetch the latest (soonest) upcoming game
    const fetchLatestGame = async () => {
        setLoading(true);
        setError(null);
        try {
            console.log('🔍 Fetching latest game...');
            const response = await fetch('http://localhost:4000/api/get-all-games', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            console.log('📥 Latest game response:', response.status);
            if (!response.ok) {
                throw new Error('Failed to fetch games');
            }
            const result = await response.json();
            console.log('📦 Latest game data:', result);
            const gamesData = Array.isArray(result) ? result : result.data;
            if (!Array.isArray(gamesData)) {
                throw new Error('Invalid data format received from API');
            }
            // Filter for future games and sort by soonest
            const now = new Date();
            const futureGames = gamesData
                .filter((g: Game) => new Date(g.startTime) > now)
                .sort((a: Game, b: Game) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
            if (futureGames.length > 0) {
                console.log('🎮 Setting next game:', futureGames[0]);
                setGame(futureGames[0]);
                setGameId(futureGames[0]._id);
            } else {
                console.log('❌ No future games found');
                setGame(null);
                setGameId(null);
                resetGameState();
            }
        } catch (err) {
            console.error('❌ Error fetching latest game:', err);
            setError(err instanceof Error ? err.message : 'Failed to fetch games');
            setGame(null);
            setGameId(null);
            resetGameState();
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchLatestGame();
    }, []);

    // Add back the interval but with 10 seconds
    useEffect(() => {
        const interval = setInterval(() => {
            console.log('⏰ 10-second interval: Fetching latest game...');
            fetchLatestGame();
        }, 10000);  // Fetch new game every 10 seconds
        return () => clearInterval(interval);
    }, []);

    // Timer effect for the latest game
    useEffect(() => {
        if (!game) {
            setTimeLeft("");
            setIsBettingDisabled(false); // Enable betting when no game
            return;
        }
        let timer: NodeJS.Timeout;
        const updateTimer = () => {
            const now = new Date();
            const startTime = new Date(game.startTime);
            const diff = startTime.getTime() - now.getTime();
            if (diff <= 0) {
                setTimeLeft("STARTING NOW!");
                setIsBettingDisabled(true); // Disable betting only when timer ends
                
                // Add 3 second delay before starting flip animation
                setTimeout(() => {
                    // If there are entries, submit them
                    if (!hasSubmittedRef.current && entriesRef.current.length > 0) {
                        hasSubmittedRef.current = true;
                        handleFinalSubmit();
                    }
                    
                    // Start coin flip animation after 3 seconds
                    setGameState('flipping');
                    setFlippingAnimation('heads');
                    
                    // Start polling for result after 8 seconds (3s delay + 5s animation)
                    setTimeout(() => {
                        console.log('⏰ Starting to poll for result...');
                        fetchResultAndShow();
                    }, 5000);
                }, 3000);
                
                return false;
            } else {
                const minutes = Math.floor(diff / 60000);
                const seconds = Math.floor((diff % 60000) / 1000);
                setTimeLeft(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
                setIsBettingDisabled(false); // Enable betting while timer is running
                return true;
            }
        };
        updateTimer();
        timer = setInterval(() => {
            const shouldContinue = updateTimer();
            if (!shouldContinue) clearInterval(timer);
        }, 1000);
        return () => clearInterval(timer);
    }, [game]);

    // Coinflip animation effect
    useEffect(() => {
        if (gameState !== 'flipping') return;
        
        let flipCount = 0;
        const totalDuration = 5000; // 5 seconds total
        const numberOfFlips = 25; // Number of flips in 5 seconds
        const intervalTime = totalDuration / numberOfFlips; // Time between each flip
        
        const animationInterval = setInterval(() => {
            setFlippingAnimation(prev => prev === 'heads' ? 'tails' : 'heads');
            flipCount++;
            
            // Stop animation after all flips
            if (flipCount >= numberOfFlips) {
                clearInterval(animationInterval);
            }
        }, intervalTime); // Evenly spaced flips over 5 seconds

        return () => {
            clearInterval(animationInterval);
        };
    }, [gameState]);

    // Add effect to handle result delay and next game
    useEffect(() => {
        if (gameState === 'result') {
            const timer = setTimeout(() => {
                setGameState('timer');
                setIsBettingDisabled(false); // Re-enable betting for next game
                hasSubmittedRef.current = false; // Reset submission flag
                setEntries([]);
                setSelected(null);
                setAmount("");
                fetchLatestGame();
            }, 5000); // Wait 5 seconds after result
            return () => clearTimeout(timer);
        }
    }, [gameState]);

    // Fetch result and show
    const fetchResultAndShow = async () => {
        if (!gameId) return;
        let retryCount = 0;
        const maxRetries = 10; // Maximum number of retries

        const tryFetchResult = async () => {
            try {
                console.log('🔍 Fetching game result for gameId:', gameId);
                const response = await fetch(`http://localhost:4000/api/get-game/${gameId}`, {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                console.log('📥 Game result response:', response.status);
                
                if (response.status === 404) {
                    console.log('❌ Game not found (404)');
                    resetGameState();
                    fetchLatestGame();
                    return;
                }

                if (!response.ok) {
                    throw new Error(`Failed to fetch game result: ${response.status}`);
                }

                const result = await response.json();
                console.log('📦 Game result data:', result);
                
                if (!result.success || !result.data) {
                    throw new Error('Invalid response format');
                }

                const gameData = result.data;
                
                // If the game exists but result is not set yet, retry
                if (!gameData.result) {
                    if (retryCount < maxRetries) {
                        retryCount++;
                        console.log(`⏳ Result not set yet, retry ${retryCount}/${maxRetries}...`);
                        setTimeout(tryFetchResult, 1000);
                        return;
                    } else {
                        console.log('❌ Max retries reached, resetting game state');
                        resetGameState();
                        fetchLatestGame();
                        return;
                    }
                }
                
                // Set the result
                const res = gameData.result.toLowerCase() as 'heads' | 'tails';
                console.log('🎲 Setting final result:', res);
                setFinalResult(res);
                setFlippingAnimation(res);
                setGameState('result');
                setResultText(`${res.charAt(0).toUpperCase() + res.slice(1)} Win!!!`);
                setTimeout(() => setShowCelebration(true), 200);
                
                // Clear entries after successful result
                setEntries([]);
                entriesRef.current = [];
                
                // Update history only when we have a final result
                fetchGameHistory();
                
                // Wait 5 seconds before fetching next game
                setTimeout(() => {
                    console.log('⏰ Result shown, fetching next game...');
                    setGameState('timer');
                    setFinalResult(null);
                    setResultText("No game yet started");
                    fetchLatestGame();
                }, 5000);
            } catch (e) {
                console.error('❌ Error fetching game result:', e);
                if (retryCount < maxRetries) {
                    retryCount++;
                    console.log(`🔄 Retrying after error (${retryCount}/${maxRetries})...`);
                    setTimeout(tryFetchResult, 1000);
                } else {
                    console.log('❌ Max retries reached after errors, resetting game state');
                    resetGameState();
                    fetchLatestGame();
                }
            }
        };

        // Start the first attempt
        tryFetchResult();
    };

    // Add a new function to reset game state
    const resetGameState = () => {
        console.log('🔄 Resetting game state');
        setGameState('timer');
        setTimeLeft("No game yet started");
        setFinalResult(null);
        setResultText("No game yet started");
        setEntries([]);
        setEntriesRef([]); // Reset the ref as well
        setSelected(null);
        setAmount("");
        setIsBettingDisabled(true);
        hasSubmittedRef.current = false; // Reset submission flag
    };

    // Entry form handlers
    const handleSelect = (option: "Heads" | "Tails") => {
        setSelected((prev) => (prev === option ? null : option));
    };
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!selected) {
            alert("Please select Heads or Tails");
            return;
        }
        if (!amount || parseInt(amount) <= 0) {
            alert("Please enter a valid amount");
            return;
        }
        // Generate a new ID
        const newId = `#${1001 + entries.length}`;
        // Create new entry
        const newEntry: BetEntry = {
            id: newId,
            option: selected,
            amount: parseInt(amount),
            timestamp: new Date(),
        };
        setEntries([newEntry, ...entries]);
        setLastAddedId(newId);
        setShowSuccess(true);
        setTimeout(() => setShowSuccess(false), 2000);
        setAmount("");
        setSelected(null);
    };
    const totalAmount = entries.reduce((sum, entry) => sum + entry.amount, 0);

    // Final submit logic
    const handleFinalSubmit = async () => {
        if (!gameId || isSubmitting) return;
        setIsSubmitting(true);
        try {
            if (entriesRef.current.length > 0) {
                console.log('📤 Submitting entries:', entriesRef.current);
                const formattedEntries = entriesRef.current.map(entry => ({
                    id: entry.id,
                    centerId: user?._id || "",
                    amount: entry.amount.toString(),
                    bet: entry.option.toLowerCase(),
                    result: ""
                }));
                console.log('📦 Formatted entries:', formattedEntries);
                const response = await fetch('http://localhost:4000/api/add-entries', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    },
                    body: JSON.stringify({
                        gameId: gameId,
                        entries: formattedEntries
                    }),
                });
                console.log('📥 Submit entries response:', response.status);
                if (!response.ok) throw new Error('Failed to submit entries');
                const result = await response.json();
                console.log('📦 Submit entries result:', result);
                if (!result.success) {
                    setError(result.message || 'Failed to submit entries');
                    setIsSubmitting(false);
                    return;
                }
                // Clear entries after successful submission
                setEntries([]);
                entriesRef.current = [];
            }
            console.log('🎮 Starting flip animation');
            setGameState('flipping');
            setFlippingAnimation('heads');
        } catch (error) {
            console.error('❌ Error submitting entries:', error);
            setError('Network error. Please try again.');
            setIsSubmitting(false);
        }
    };

    useEffect(() => {
        fetchPoints(user?._id || "");
    }, [user]);

    const fetchPoints = async (centerId: string) => {
        if (!centerId) return;
        try {
            console.log('🔍 Fetching points for centerId:', centerId);
            const response = await fetch(`http://localhost:4000/api/get-points/${centerId}`);
            console.log('📥 Points response:', response.status);
            if (!response.ok) {
                throw new Error('Failed to fetch points');
            }
            const result = await response.json();
            console.log('📦 Points data:', result);
            if (result.success) {
                console.log('💰 Setting user points:', result.data);
                setUserPoints(result.data);
            }
        } catch (error) {
            console.error('❌ Error fetching points:', error);
        }
    };

    // Fetch user's game history
    const fetchGameHistory = async () => {
        if (!user?._id) return;
        setHistoryLoading(true);
        try {
            console.log('🔍 Fetching game history for user:', user._id);
            const response = await fetch(
                `http://localhost:4000/api/get-all-games/${user._id}`,
                {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                }
            );
            console.log('📥 History response:', response.status);
            if (!response.ok) throw new Error("Failed to fetch history");
            const data = await response.json();
            console.log('📦 History data:', data);
            if (data.success && data.data) {
                const sortedGames = data.data
                    .sort(
                        (a: GameHistory, b: GameHistory) =>
                            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                    )
                    .slice(0, 5);
                console.log('📚 Setting history games:', sortedGames);
                setHistoryGames(sortedGames);
            }
        } catch (e) {
            console.error('❌ Error fetching game history:', e);
        } finally {
            setHistoryLoading(false);
        }
    };

    // Add this helper function near your other utility functions
    const getRecentResults = (games: GameHistory[]) => {
        // Get the last 10 games (or fewer if not available)
        const recentGames = games
            .filter(game => game.result && (game.result.toLowerCase() === 'heads' || game.result.toLowerCase() === 'tails')) // Only include games with valid results
            .slice(0, 10) // Get last 10 games
            .map(game => game.result.toLowerCase().charAt(0).toUpperCase()) // Convert to H/T
            .reverse(); // Reverse to show oldest to newest

     
        return recentGames;
    };

    // Add a helper function to update entriesRef
    const setEntriesRef = (newEntries: BetEntry[]) => {
        entriesRef.current = newEntries;
    };

    // Update the useEffect for entriesRef to use the new helper
    useEffect(() => {
        setEntriesRef(entries);
    }, [entries]);

    // Update useEffect to fetch history when user changes
    useEffect(() => {
        if (user?._id) {
            fetchGameHistory();
        }
    }, [user]);

    return (
        <ProtectedRoute>
            <div className=" min-h-screen w-full flex flex-col md:items-center md:justify-center bg-cover bg-center relative" style={{ backgroundImage: 'url(/static/img/coinflipbg.png)' }}>
                <div className="absolute inset-0 bg-gradient-to-r from-[#040404] to-transparent z-0"></div>
                <div className="hidden w-full h-[100vh] overflow-hidden md:flex flex-row items-stretch justify-center gap-[20px] z-10 px-[20px] py-[20px]">
                    {/* Left Panel */}
                    <div className="w-[25%]  rounded-2xl bg-white/20 backdrop-blur-lg p-7 md:p-8 flex flex-col gap-7 shadow-xl border border-white/30 h-full justify-between no-scroll overflow-y-scroll">
                        <div>
                            <div className="rounded-xl bg-[#a78a40] p-5 text-white flex flex-col items-start">
                                <span className="font-light text-lg">Total Craze Points</span>
                                <span className="font-[regularFont] text-2xl mt-2">{userPoints.toLocaleString()}</span>
                            </div>
                            <div className="flex flex-col gap-4 mt-6">
                                <div className="flex items-center justify-between">
                                    <span className="text-white font-light">History</span>
                                    <a href="/history" className="text-white underline underline-offset-4 font-light">All History</a>
                                </div>
                                {historyLoading ? (
                                    <div className="rounded-xl bg-[#3e3e3efe] p-3 flex items-center justify-center text-white">
                                        Loading...
                                    </div>
                                ) : historyGames.length === 0 ? (
                                    <div className="rounded-xl bg-[#3e3e3efe] p-3 flex items-center justify-center text-white">
                                        No history yet
                                    </div>
                                ) : (
                                    historyGames.map((game) => {
                                        // Find user's entries for this game
                                        const userEntries = game.entries.filter(e => e.centerId === user?._id);
                                        const totalAmount = userEntries.reduce((sum, e) => sum + parseInt(e.amount), 0);
                                        return (
                                            <div key={game._id} className="rounded-xl bg-[#3e3e3efe] p-3 flex flex-col gap-2">
                                                <div className={`rounded-full px-5 py-2 text-white text-sm font-medium w-full text-center ${game.result === "heads" ? "bg-[#F049FF]" : "bg-[#17FF83]"} text-[#202020]`}>
                                                    Winner ({game.result ? game.result.charAt(0).toUpperCase() + game.result.slice(1) : "?"}) - ₹{totalAmount}
                                                </div>
                                                <div className="flex gap-2 w-full">
                                                    <div className="bg-[#ffffff50] border border-[#ffffff50] rounded-full px-5 py-2 text-white text-xs w-1/2 text-center">
                                                        {userEntries.length} {userEntries.length === 1 ? "Entry" : "Entries"}
                                                    </div>
                                                    <a href="/history" className="text-white underline underline-offset-4 font-light w-1/2 flex items-center justify-center text-xs">
                                                        View Details
                                                    </a>
                                                </div>
                                            </div>
                                        );
                                    })
                                )}
                            </div>
                        </div>
                    </div>
                    {/* Center Panel */}
                    <div className=" w-[50%] flex flex-col gap-7 rounded-2xl bg-white/20 backdrop-blur-lg p-[20px] overflow-y-scroll shadow-xl border border-white/30 h-full justify-between no-scroll">
                        {/* Previous winner list */}
                        <div>
                            <div className="rounded-xl bg-white/10 p-4 flex flex-col gap-2 items-center overflow-hidden">
                                <span className="text-white font-light">Previous winner list :</span>
                                <div className="relative w-full overflow-hidden">
                                    {historyLoading ? (
                                        <div className="w-full text-center py-2">
                                            <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin mx-auto"></div>
                                        </div>
                                    ) : getRecentResults(historyGames).length === 0 ? (
                                        <div className="text-white/70 text-sm">No previous games</div>
                                    ) : (
                                        <div className="flex flex-wrap gap-2 justify-center">
                                            <div className="w-full text-center text-white/70 text-sm mb-2">Latest 10 Winners</div>
                                            {getRecentResults(historyGames).map((result, i) => (
                                                <span
                                                    key={i}
                                                    className={`min-w-[32px] min-h-[32px] flex items-center justify-center rounded-full font-bold text-lg ${
                                                        result === "H"
                                                            ? "bg-[#F049FF] text-[#7B1177]"
                                                            : "bg-[#17FF83] text-[#056048]"
                                                    }`}
                                                >
                                                    {result}
                                                </span>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                        {/* Timer, Animation, or Result */}
                        <div className="flex flex-col items-center justify-center flex-grow min-h-[340px] relative">
                            {gameState === 'timer' && (
                                <>
                                    <span className="text-white font-light text-lg">Game will start in</span>
                                    <span className="text-white font-[mediumFont] text-4xl md:text-5xl tracking-wider">{timeLeft}</span>
                                    <span className="text-white text-center font-light mt-2">place your bid after the time end<br />you will not able to place bid</span>
                                    {/* Button to leave the current game room */}
                                 
                                </>
                            )}
                            {gameState === 'flipping' && (
                                <div className="flex flex-col items-center justify-center w-full">
                                    <div className="relative flex justify-center items-center">
                                        <div className="absolute w-[320px] h-[320px] bg-[#ffffff10] rounded-full animate-pulse"></div>
                                        <img
                                            src={`/static/img/${flippingAnimation}.gif`}
                                            className="w-[300px] h-auto z-10 animate-spin-slow"
                                            alt="coin flipping"
                                        />
                                    </div>
                                    <p className="text-[1.2rem] font-extralight text-white mt-4 animate-pulse">
                                        Coin is Flipping...
                                    </p>
                                </div>
                            )}
                            {gameState === 'result' && (
                                <div className="flex flex-col items-center justify-center w-full relative">
                                    <div className="absolute inset-0 z-10 pointer-events-none">
                                        <img
                                            src="/static/img/celebrate.gif"
                                            className="w-full h-full object-cover opacity-70"
                                            alt="celebration"
                                        />
                                    </div>
                                    <div className="relative flex items-center justify-center w-[300px] h-[300px] z-20">
                                        <div className="absolute w-[320px] h-[320px] bg-[#ffffff10] rounded-full animate-pulse"></div>
                                        <img
                                            src={`/static/img/${finalResult}.png`}
                                            className="w-[300px] h-auto z-20 absolute"
                                            alt={finalResult ? `${finalResult} side of coin` : " "}
                                        />
                                    </div>
                                    <div className="w-full flex flex-col items-center gap-[15px] justify-center mt-8 z-20">
                                        <h2 className="text-[2.5rem] font-[mediumFont] text-white animate-bounce capitalize">
                                            {resultText}
                                        </h2>
                                        {/* <button
                                            onClick={() => window.location.reload()}
                                            className="gold-button h-[45px] w-[200px] text-[1rem] font-[regularFont] mt-4"
                                        >
                                            Play Again
                                        </button> */}
                                    </div>
                                </div>
                            )}
                        </div>
                        {/* Options and Amount Form */}
                        <form onSubmit={handleSubmit} className="rounded-xl bg-white/30 p-6 flex flex-col gap-4 items-center">
                            <div className="flex w-full gap-4 mb-2">
                                <button 
                                    type="button" 
                                    onClick={() => handleSelect("Heads")} 
                                    disabled={isBettingDisabled}
                                    className={`flex-1 py-3 rounded-full font-[mediumFont] text-lg transition ${
                                        selected === "Heads" 
                                            ? "bg-gradient-to-r from-yellow-400 to-yellow-300 text-white shadow" 
                                            : "bg-white text-[#404040]"
                                    } ${isBettingDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                                >
                                    Heads
                                </button>
                                <button 
                                    type="button" 
                                    onClick={() => handleSelect("Tails")} 
                                    disabled={isBettingDisabled}
                                    className={`flex-1 py-3 rounded-full font-[mediumFont] text-lg transition ${
                                        selected === "Tails" 
                                            ? "bg-gradient-to-r from-[#a78a40] to-[#F049FF] text-white shadow" 
                                            : "bg-white text-[#404040]"
                                    } ${isBettingDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                                >
                                    Tails
                                </button>
                            </div>
                            <div className="flex w-full gap-3 mb-2">
                                {[100, 200, 500, 1000].map(val => (
                                    <button 
                                        type="button" 
                                        key={val} 
                                        onClick={() => setAmount(val.toString())} 
                                        disabled={isBettingDisabled}
                                        className={`flex-1 py-2 rounded-full bg-[#ffffff20] border border-[#ffffff50] text-white font-[regularFont] text-base hover:bg-yellow-100/20 transition ${
                                            isBettingDisabled ? 'opacity-50 cursor-not-allowed' : ''
                                        }`}
                                    >
                                        {val} Rs
                                    </button>
                                ))}
                            </div>
                            <div className="flex w-full gap-3">
                                <input 
                                    type="number" 
                                    placeholder="Enter your amount" 
                                    className="flex-1 px-5 py-2 rounded-full border border-[#ffffff50] bg-[#ffffff20] text-white placeholder:text-white font-[regularFont] outline-none" 
                                    value={amount} 
                                    onChange={e => setAmount(e.target.value)}
                                    disabled={isBettingDisabled}
                                />
                                <button 
                                    type="submit" 
                                    disabled={isBettingDisabled}
                                    className={`px-6 py-2 rounded-full bg-gradient-to-r from-green-400 to-green-500 text-white font-[mediumFont] shadow hover:from-green-500 hover:to-green-600 transition ${
                                        isBettingDisabled ? 'opacity-50 cursor-not-allowed' : ''
                                    }`}
                                >
                                    Add member
                                </button>
                            </div>
                        </form>
                    </div>
                    {/* Right Panel */}
                    <div className="w-[25%] flex-shrink-0 rounded-2xl bg-white/20 backdrop-blur-lg p-7 md:p-8 flex flex-col gap-7 shadow-xl border border-white/30 h-full justify-between">
                        <div>
                            <div className="rounded-xl bg-white/80 p-5 flex flex-col gap-2">
                                <div className="flex items-center justify-between">
                                    <span className="text-[#202020] font-light">Total Bid</span>
                                    <span className="text-[#202020] font-[regularFont] text-lg">{totalAmount}</span>
                                </div>
                                <div className="flex items-center justify-between mt-2">
                                    <span className="flex items-center gap-2 text-[#202020] font-light"><span className="w-4 h-4 bg-[#f04aff] rounded-full inline-block"></span>Heads</span>
                                    <span className="text-[#202020] font-[regularFont]">{entries.filter(e => e.option === "Heads").reduce((sum, e) => sum + e.amount, 0)}</span>
                                </div>
                                <div className="flex items-center justify-between mt-2">
                                    <span className="flex items-center gap-2 text-[#202020] font-light"><span className="w-4 h-4 bg-[#17FF83] rounded-full inline-block"></span>Tails</span>
                                    <span className="text-[#202020] font-[regularFont]">{entries.filter(e => e.option === "Tails").reduce((sum, e) => sum + e.amount, 0)}</span>
                                </div>
                            </div>
                        </div>
                        <div className="flex-1 flex flex-col justify-end">
                            <h3 className="text-white font-[regularFont] text-lg mb-4">Entries</h3>
                            <div className="flex flex-col gap-3">
                                {entries.length === 0 ? (
                                    <div className="w-full text-center py-4 text-white bg-[#ffffff20] rounded-lg backdrop-blur-sm">
                                        <p className="text-lg font-light">No entries yet</p>
                                    </div>
                                ) : (
                                    entries.map((entry, idx) => (
                                        <div key={idx} className="flex items-center gap-2 p-2 bg-[#ffffff50] rounded-xl">
                                            <span className="flex-1 h-10 flex items-center justify-center text-[#5d5d5d] bg-[#ffffff20] border border-[#ffffff50] rounded-full font-[regularFont]">{entry.id}</span>
                                            <span className={`flex-1 h-10 flex items-center justify-center px-5 rounded-full font-[mediumFont] text-base ${entry.option === "Heads" ? "bg-[#F049FF] text-[#7B1177]" : "bg-[#17FF83] text-[#056048]"}`}>{entry.option}</span>
                                            <span className="flex-1 h-10 flex items-center justify-center text-white bg-[#ffffff20] border border-[#ffffff50] rounded-full font-[regularFont] green-button2">{entry.amount}₹</span>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>
                </div>
                {/* Mobile View */}
                <div className="md:hidden w-full relative h-[100vh] z-40">
                    <header className="h-[10vh] border-b border-[#747474] flex items-center justify-between p-[20px]">
                        <h1 className="text-[20px]  text-white"> <span className="font-[lightFont]">Coin</span><span className="font-[mediumFont]">Craze</span></h1>
                        <div className="h-[40px] w-[40px] aspect-square flex items-center justify-center">

                        </div>
                    </header>

                    <div className="h-[90vh] flex flex-col gap-[20px] w-full px-[10px] py-[10px]" >
                        <div className="w-full flex items-center justify-end">
                            <div className="px-[10px] h-[40px] text-[14px] font-[regularFont] flex items-center justify-center gold-button">300 CrazeCoins</div>
                        </div>
                        <div className="w-full flex gap-[30px] overflow-x-scroll no-scroll items-center justify-between overflow-hidden p-[15px] bg-[#ffffff50] backdrop-blur-lg border border-[#767676] rounded-[10px] ">
                            <div className="w-fit ">
                                <h3 className="text-[14px] text-white text-nowrap font-[regularFont] tracking-wider">Total Bid</h3>
                                <h1 className="text-[20px] text-nowrap font-[regularFont] text-white">₹20000</h1>
                            </div>
                            <div className="min-w-[1px] h-[50px] bg-gradient-to-t from-transparent via-white to-transparent "></div>
                            <div className="w-fit ">
                                <div className="flex items-center gap-[10px]">
                                    <div className="w-[10px] h-[10px] aspect-square bg-[#F049FF] rounded-full"></div>
                                    <h3 className="text-[14px] text-white text-nowrap font-[regularFont] tracking-wider">Heads</h3>
                                </div>
                                <h1 className="text-[20px] text-nowrap font-[regularFont] text-white">₹20000</h1>
                            </div>
                            <div className="min-w-[1px] h-[50px] bg-gradient-to-t from-transparent via-white to-transparent "></div>
                            <div className="w-fit ">
                                <div className="flex items-center gap-[10px]">
                                    <div className="w-[10px] h-[10px] aspect-square bg-[#17FF83] rounded-full"></div>
                                    <h3 className="text-[14px] text-white text-nowrap font-[regularFont] tracking-wider">Tails</h3>
                                </div>
                                <h1 className="text-[20px] text-nowrap font-[regularFont] text-white">₹20000</h1>
                            </div>


                        </div>
                        <div className="w-full flex items-center gap-[20px]">
                            <button className="px-[20px] h-[40px] w-full flex items-center justify-center font-[regularFont] text-[14px] bg-[#ffffff50] text-white tracking-wider backdrop-blur-md rounded-[8px] overflow-hidden border border-[#767676]">History</button>
                            <button className="green-button3  px-[20px] w-full h-[40px] flex items-center justify-center font-[regularFont] text-[14px] rounded-[8px]">Add Member</button>
                        </div>
                        <div className="w-full h-full rounded-[10px] bg-[#ffffff50] backdrop-blur-lg border border-[#767676]">

                        </div>
                    </div>


                </div>

                {/* Mobile View Sidebar */}
                <div id="overlay" className="w-full h-screen fixed top-0 bottom-0 left-0 right-0 bg-[#00000050] backdrop-blur-lg z-40 hidden"></div>
            
                <div className="hidden md:hidden w-full h-[90vh] bg-white fixed left-0 bottom-0 right-0 z-50 border-t-[8px] border-amber-300 rounded-t-[50px] overflow-y-scroll no-scroll">
                    <div className="w-full flex items-center gap-[10px] justify-center mt-[20px]">
                        <p className="px-[20px] py-[6px] rounded-full bg-[#3E3E3E] text-[13px] text-white text-center w-fit">8 Members are playing now</p>
                        <p className="px-[20px] py-[6px] rounded-full bg-[#3E3E3E] text-[13px] text-white text-center w-fit">Close</p>

                    </div>
                    <form action="" className="p-[20px] flex flex-col gap-[20px]">
                        <div>
                            <label htmlFor="" className="font-[regularFont]"> Option</label>
                            <div className="w-full flex items-center gap-[20px]">
                                <button className="w-full px-[20px] py-[10px] font-[regularFont] gold-button2 rounded-full overflow-hidden">Heads</button>
                                <button className="bg-slate-100 rounded-full font-[regularFont] border-[2px] border-slate-300 w-full px-[20px] py-[10px]">Tails</button>
                            </div>
                        </div>
                        <div className="flex flex-col gap-[10px]">
                            <label htmlFor="" className="font-[regularFont]">Amount</label>
                            <div className="w-full flex flex-wrap gap-x-[10px] gap-y-[5px]">
                                <div className="px-[20px] font-[regularFont] border border-slate-300 rounded-full py-[10px]">
                                    100
                                </div>
                                <div className="px-[20px] font-[regularFont] border border-slate-300 rounded-full py-[10px]">
                                    200
                                </div>
                                <div className="px-[20px] font-[regularFont] border border-slate-300 rounded-full py-[10px]">
                                    500
                                </div>
                                <div className="px-[20px] font-[regularFont] border border-slate-300 rounded-full py-[10px]">
                                    1000
                                </div>
                            </div>
                            <input type="number" className="px-[20px] w-full font-[regularFont] rounded-full py-[10px] border border-slate-300" name="" id="" placeholder="Enter your amount" />
                            <button className="px-[20px] py-[10px] green-button4 font-[regularFont] rounded-full">Add member</button>
                        </div>
                    </form>
                    <div className="p-[20px]">
                        <h3 className=" font-[regularFont]">Entires</h3>
                        <div className="w-full flex flex-col gap-[10px]">
                            <div className="p-[10px] bg-slate-100 rounded-[10px]">
                                <div className="flex items-center gap-[10px]">
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">#1001</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">Heads</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center green-button4">200</div>

                                </div>
                            </div>
                            <div className="p-[10px] bg-slate-100 rounded-[10px]">
                                <div className="flex items-center gap-[10px]">
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">#1001</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">Heads</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center green-button4">200</div>

                                </div>
                            </div>
                            <div className="p-[10px] bg-slate-100 rounded-[10px]">
                                <div className="flex items-center gap-[10px]">
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">#1001</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">Heads</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center green-button4">200</div>

                                </div>
                            </div>
                            <div className="p-[10px] bg-slate-100 rounded-[10px]">
                                <div className="flex items-center gap-[10px]">
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">#1001</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">Heads</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center green-button4">200</div>

                                </div>
                            </div>
                            <div className="p-[10px] bg-slate-100 rounded-[10px]">
                                <div className="flex items-center gap-[10px]">
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">#1001</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center">Heads</div>
                                    <div className="px-[10px] py-[6px] text-[12px] bg-slate-200 rounded-full font-[regularFont] w-full flex items-center justify-center green-button4">200</div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </ProtectedRoute>
    );
}

