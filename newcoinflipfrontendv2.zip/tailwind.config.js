module.exports = {
  extend: {
    animation: {
      'spin-slow': 'spin 1s linear infinite',
    },
  },
}; 