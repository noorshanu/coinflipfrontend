https://coin-flip-backend-nishantpacharne-nishantpacharnes-projects.vercel.app

http//localhost:4000